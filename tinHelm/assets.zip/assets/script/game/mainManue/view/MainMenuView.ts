import { CCView } from 'db://oops-framework/module/common/CCView';
import { _decorator } from 'cc';
import { MainMenu } from '../MainMenu';
import { ecs } from 'db://oops-framework/libs/ecs/ECS';
import { smc } from '../../common/SingletonModuleComp';
import { gui } from 'db://oops-framework/core/gui/Gui';
import { LayerType } from 'db://oops-framework/core/gui/layer/LayerEnum';
import { tween } from 'cc';
import { Vec3 } from 'cc';
import { TweenAnimUtil } from 'db://oops-framework/core/utils/TweenAnimUtil';
const { ccclass } = _decorator;

@ccclass("MainMenuView")
@ecs.register("MainMenuView", false)
@gui.register('MainMenuView', { layer: LayerType.UI, prefab: 'gui/mainMenu/ui/MainMenuView' })
export class MainMenuView extends CCView<MainMenu> {
    private isBtnStartShow = false
    private isCanContinueShow = false


    start() {
        this.nodeTreeInfoLite();
        this.setButton();
        this.refresh();
    }

    refresh() {
        const btnContinue = this.getNode("btnContinue");
        if (btnContinue) {
            btnContinue.active = this.ent.hasSave();
        }
    }

    btnContinue() {
        if (this.isCanContinueShow) {
            console.log("点击继续")
        } else {
            const btnContinue = this.getNode("btnContinue");
            TweenAnimUtil.move(btnContinue!, -300, 0);
            this.isCanContinueShow = true
        }
    }

    btnStart() {
        if (this.isBtnStartShow) {
            console.log("点击继续")
        } else {
            const btnStart = this.getNode("btnStart");
            TweenAnimUtil.move(btnStart!, -300, 0, 0.5, () => {
                this.isBtnStartShow = true
            });
        }
    }


    btnHide() {
        if (this.isBtnStartShow) {
            const btnStart = this.getNode("btnStart");
            TweenAnimUtil.move(btnStart!, 300, 0, 0.5, () => {
                this.isBtnStartShow = false
            });
        }
        if (this.isCanContinueShow) {
            const btnContinue = this.getNode("btnContinue");
            TweenAnimUtil.move(btnContinue!, 300, 0);
            this.isCanContinueShow = false
        }
    }

    btnProfile() {
        this.ent.openProfileDialog();
    }



    reset() {

    }


}