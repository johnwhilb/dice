import { CCBusiness } from 'db://oops-framework/module/common/CCBusiness';

import { Profile } from '../Profile';

export class B_Profile_Avatar
    extends CCBusiness<Profile> {


    changeAvatar(id: number) {

    }

    unlockAvatar(id: number) {

    }


}