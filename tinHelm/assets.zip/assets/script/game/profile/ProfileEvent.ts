export enum ProfileEvent {
    /**
     * 当前看板娘变化
     */
    AvatarChanged = "AvatarChanged",

    /**
     * 新角色解锁
     */
    AvatarUnlocked = "AvatarUnlocked",


}