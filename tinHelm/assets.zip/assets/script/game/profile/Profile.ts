import { CCEntity } from 'db://oops-framework/module/common/CCEntity';
import { ProfileDialog } from './view/ProfileDialog';
import { ecs } from 'db://oops-framework/libs/ecs/ECS';

@ecs.register('Profile')
export class Profile extends CCEntity {

    ProfileDialog!: ProfileDialog

    open() {
        if (this.has(ProfileDialog)) {
            return Promise.resolve(this.ProfileDialog.node);
        }
        this.addUi(ProfileDialog);
    }
}