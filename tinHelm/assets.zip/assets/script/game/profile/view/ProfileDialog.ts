import { CCView } from 'db://oops-framework/module/common/CCView';
import { _decorator } from 'cc';
import { ecs } from 'db://oops-framework/libs/ecs/ECS';
import { gui } from 'db://oops-framework/core/gui/Gui';
import { LayerType } from 'db://oops-framework/core/gui/layer/LayerEnum';

import { Profile } from '../Profile';
const { ccclass } = _decorator;

@ccclass("ProfileDialog")
@ecs.register("ProfileDialog", false)
@gui.register('ProfileDialog', { layer: LayerType.PopUp, prefab: 'gui/profile/ProfileDialog', vacancy: true, mask: true, destroy: true })
export class ProfileDialog extends CCView<Profile> {

    start() {
        this.nodeTreeInfoLite();
        this.setButton();
        this.refresh();
    }

    refresh() {
    }

    reset() {

    }


}