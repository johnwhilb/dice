import { ecs } from 'db://oops-framework/libs/ecs/ECS';


@ecs.register('M_Profile_Avatar')
export class M_Profile_Avatar extends ecs.Comp {
    currentAvatarId: number = 0;

    unlockedAvatarIds: number[] = [];

    reset() {
        this.currentAvatarId = 0;
        this.unlockedAvatarIds.length = 0;
    }


}