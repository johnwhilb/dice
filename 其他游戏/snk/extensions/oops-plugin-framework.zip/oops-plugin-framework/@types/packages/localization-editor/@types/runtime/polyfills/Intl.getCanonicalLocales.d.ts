import '@formatjs/intl-getcanonicallocales';
